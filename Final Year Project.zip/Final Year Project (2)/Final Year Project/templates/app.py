from flask import Flask, render_template, request, flash, redirect, url_for
from flask_mail import Mail, Message
from dotenv import load_dotenv
import os
from os import path
import logging
import traceback
from functools import wraps
from flask import session, jsonify, make_response
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import json
import datetime
from base64 import b64decode

# Load environment variables
load_dotenv()

# If app.py sits inside a folder named 'templates', set the template_folder to the nested templates directory
root_dir = path.dirname(__file__)
templates_dir = path.join(root_dir, 'templates') if path.isdir(path.join(root_dir, 'templates')) else root_dir
app = Flask(__name__, template_folder=templates_dir)
app.secret_key = os.getenv('SECRET_KEY', 'fallback-secret-key')

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Email configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False
app.config['MAIL_USERNAME'] = os.getenv('EMAIL_ADDRESS')
app.config['MAIL_PASSWORD'] = os.getenv('EMAIL_PASSWORD')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('EMAIL_ADDRESS') or 'no-reply@unizulu.local'
# Suppress sending by default in DEBUG or if explicitly set
app.config['MAIL_SUPPRESS_SEND'] = os.getenv('MAIL_SUPPRESS_SEND', '').lower() == 'true' or (os.getenv('DEBUG', 'False').lower() == 'true')
# Allow admin-controlled real sends only when enabled in environment
app.config['ALLOW_REAL_SENDS'] = os.getenv('ALLOW_REAL_SENDS', '').lower() == 'true'
# Admin credentials (plain) and hashed password
ADMIN_USER = os.getenv('ADMIN_USER', 'admin')
ADMIN_PASS = os.getenv('ADMIN_PASS', 'admin')
ADMIN_PASS_HASH = os.getenv('ADMIN_PASS_HASH') or generate_password_hash(ADMIN_PASS)

# Flask-Login setup
login_manager = LoginManager()
login_manager.login_view = 'admin_login'
login_manager.init_app(app)


class AdminUser(UserMixin):
    def __init__(self, id='admin'):
        self.id = id


@login_manager.user_loader
def load_user(user_id):
    if user_id == ADMIN_USER:
        return AdminUser(id=user_id)
    return None

mail = Mail(app)

# Startup checks
if not app.config.get('MAIL_USERNAME') or not app.config.get('MAIL_PASSWORD'):
    logger.warning('MAIL_USERNAME or MAIL_PASSWORD is not set. Email sending will fail until these are provided.')

def validate_form_data(data):
    """Validate form data"""
    errors = []
    
    # Required fields validation
    if not data.get('studentName', '').strip():
        errors.append('Student name is required')
    
    if not data.get('riskLevel', '').strip():
        errors.append('Risk level is required')
    
    if not data.get('alertMessage', '').strip():
        errors.append('Alert message is required')
    
    # Email validation (if provided)
    student_email = data.get('studentEmail', '').strip()
    if student_email and '@' not in student_email:
        errors.append('Please provide a valid email address')
    
    # Length validation
    if len(data.get('alertMessage', '')) > 1000:
        errors.append('Alert message must not exceed 1000 characters')
    
    if len(data.get('recommendations', '')) > 500:
        errors.append('Recommendations must not exceed 500 characters')
    
    return errors

def send_risk_alert(form_data):
    """Send risk alert email"""
    try:
        # Prepare email content
        subject = f"Unizulu Risk Alert - {form_data['riskLevel']} Risk Level - {form_data['studentName']}"
        
        # Create email body
        body = f"""
UNIZULU RISK ALERT SYSTEM - NEW ALERT SUBMISSION

STUDENT INFORMATION:
-------------------
Name: {form_data['studentName']}
Email: {form_data.get('studentEmail', 'Not provided')}

RISK ASSESSMENT:
----------------
Risk Level: {form_data['riskLevel']}

ALERT DETAILS:
--------------
{form_data['alertMessage']}

RECOMMENDATIONS & NEXT STEPS:
-----------------------------
{form_data.get('recommendations', 'Not provided')}

---
This alert was submitted through the Unizulu Risk Alert System.
Please take appropriate action based on the risk level indicated.
"""

        # Build recipients list: include student email if present and valid; include TO_MAIL admin copy
        student_email = form_data.get('studentEmail', '').strip()
        recipients = []
        to_mail_env = os.getenv('TO_MAIL')
        if student_email and '@' in student_email:
            recipients.append(student_email)
        if to_mail_env and to_mail_env not in recipients:
            recipients.append(to_mail_env)

        # Create and send message inside application context
        with app.app_context():
            msg = Message(
                subject=subject,
                recipients=recipients,
                body=body,
                sender=app.config.get('MAIL_DEFAULT_SENDER')
            )
            # Build a basic HTML version
            html_body = f"<h2>UNIZULU RISK ALERT</h2><p><strong>Student:</strong> {form_data['studentName']} ({form_data.get('studentEmail','Not provided')})</p><p><strong>Risk Level:</strong> {form_data['riskLevel']}</p><hr><p>{form_data['alertMessage'].replace('\n','<br>')}</p><hr><p><strong>Recommendations:</strong><br>{form_data.get('recommendations','Not provided').replace('\n','<br>')}</p>"
            msg.html = html_body

            # If sending suppressed or SMTP creds missing, write to outbox with metadata
            if app.config.get('MAIL_SUPPRESS_SEND') or not (app.config.get('MAIL_USERNAME') and app.config.get('MAIL_PASSWORD')):
                outbox_dir = path.join(root_dir, '..', 'outbox') if path.basename(root_dir) == 'templates' else path.join(root_dir, '..', 'outbox')
                # ensure outbox exists
                os.makedirs(outbox_dir, exist_ok=True)
                fname_base = f"alert_{datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')}_{form_data.get('studentName','unknown').replace(' ','_') }"
                eml_path = path.join(outbox_dir, fname_base + '.eml')
                meta_path = path.join(outbox_dir, fname_base + '.json')
                with open(eml_path, 'w', encoding='utf-8') as f:
                    f.write(f"From: {msg.sender}\n")
                    f.write(f"To: {', '.join(msg.recipients or [])}\n")
                    f.write(f"Subject: {msg.subject}\n\n")
                    f.write(msg.body or '')
                meta = {
                    'filename': os.path.basename(eml_path),
                    'subject': msg.subject,
                    'recipients': msg.recipients or [],
                    'sender': msg.sender,
                    'ts': datetime.datetime.utcnow().isoformat() + 'Z',
                }
                with open(meta_path, 'w', encoding='utf-8') as mf:
                    json.dump(meta, mf)
                logger.info(f"Saved message to outbox: {eml_path}")
                return True

            # Send email
            mail.send(msg)
        logger.info(f"Risk alert sent successfully for student: {form_data['studentName']}")
        return True

    except Exception as e:
        # Log full traceback for easier debugging
        logger.exception('Failed to send email')
        return False


@app.route('/_debug_smtp')
def debug_smtp():
    """Local-only route to test SMTP connection and login using configured credentials.

    Note: this route is intentionally simple and should only be used during development on a
    local machine. It returns a short success/error message.
    """
    # Only allow from localhost for safety
    if request.remote_addr not in ('127.0.0.1', '::1', 'localhost'):
        return ('Not allowed', 403)

    try:
        import smtplib

        server = smtplib.SMTP(app.config.get('MAIL_SERVER', 'smtp.gmail.com'), app.config.get('MAIL_PORT', 587), timeout=15)
        server.ehlo()
        if app.config.get('MAIL_USE_TLS'):
            server.starttls()
            server.ehlo()
        username = app.config.get('MAIL_USERNAME')
        password = app.config.get('MAIL_PASSWORD')
        server.login(username, password)
        server.quit()
        return ('SMTP login successful', 200)
    except Exception:
        logger.exception('SMTP debug/login failed')
        return (f'SMTP login failed: see server logs for details', 500)


def requires_admin(f):
    @wraps(f)
    @login_required
    def decorated(*args, **kwargs):
        return f(*args, **kwargs)
    return decorated


@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        user = request.form.get('username')
        pwd = request.form.get('password')
        if user == ADMIN_USER and check_password_hash(ADMIN_PASS_HASH, pwd):
            login_user(AdminUser(id=user))
            flash('Logged in as admin', 'success')
            nxt = request.args.get('next') or url_for('admin_outbox')
            return redirect(nxt)
        else:
            flash('Invalid credentials', 'danger')
    return render_template('admin_login.html')


@app.route('/admin/logout')
def admin_logout():
    logout_user()
    flash('Logged out', 'info')
    return redirect(url_for('index'))


@app.route('/admin/outbox')
@requires_admin
def admin_outbox():
    outbox_dir = path.join(root_dir, '..', 'outbox') if path.basename(root_dir) == 'templates' else path.join(root_dir, '..', 'outbox')
    items = []
    if path.isdir(outbox_dir):
        for name in sorted(os.listdir(outbox_dir), reverse=True):
            if name.lower().endswith('.json'):
                try:
                    with open(path.join(outbox_dir, name), 'r', encoding='utf-8') as mf:
                        meta = json.load(mf)
                        items.append(meta)
                except Exception:
                    logger.exception('Failed to read outbox metadata: %s', name)
    return render_template('admin_outbox.html', items=items)


@app.route('/admin/outbox/preview')
@requires_admin
def admin_outbox_preview():
    fname = request.args.get('file')
    outbox_dir = path.join(root_dir, '..', 'outbox') if path.basename(root_dir) == 'templates' else path.join(root_dir, '..', 'outbox')
    eml_path = path.join(outbox_dir, fname)
    if not path.isfile(eml_path):
        return ("Not found", 404)
    with open(eml_path, 'r', encoding='utf-8') as f:
        return f.read()


@app.route('/admin/outbox/resend', methods=['POST'])
@requires_admin
def admin_outbox_resend():
    if not app.config.get('ALLOW_REAL_SENDS'):
        flash('Resend is disabled. Enable ALLOW_REAL_SENDS to allow resends.', 'danger')
        return redirect(url_for('admin_outbox'))
    filename = request.form.get('filename')
    outbox_dir = path.join(root_dir, '..', 'outbox') if path.basename(root_dir) == 'templates' else path.join(root_dir, '..', 'outbox')
    meta_path = path.join(outbox_dir, filename)
    if not path.isfile(meta_path):
        flash('Metadata file not found in outbox', 'danger')
        return redirect(url_for('admin_outbox'))
    try:
        with open(meta_path, 'r', encoding='utf-8') as mf:
            meta = json.load(mf)
        eml_path = path.join(outbox_dir, meta.get('filename'))
        if not path.isfile(eml_path):
            flash('EML file missing for metadata', 'danger')
            return redirect(url_for('admin_outbox'))
        with open(eml_path, 'r', encoding='utf-8') as ef:
            content = ef.read()
        parts = content.split('\n\n', 1)
        body = parts[1] if len(parts) > 1 else ''
        subject = meta.get('subject', '')
        recipients = meta.get('recipients', [])
        sender = meta.get('sender', app.config.get('MAIL_DEFAULT_SENDER'))
        msg = Message(subject=subject, recipients=recipients, body=body, sender=sender)
        mail.send(msg)
        flash(f"Resent {meta.get('filename')} successfully", 'success')
    except Exception:
        logger.exception('Failed to resend outbox message')
        flash('Failed to resend message. See server logs.', 'danger')
    return redirect(url_for('admin_outbox'))

@app.route('/', methods=['GET', 'POST'])
def index():
    # Pass the recipient email to the template
    to_mail = os.getenv('TO_MAIL', 'unizulurisk@gmail.com')
    
    if request.method == 'POST':
        # Get form data
        form_data = {
            'studentName': request.form.get('studentName', '').strip(),
            'studentEmail': request.form.get('studentEmail', '').strip(),
            'riskLevel': request.form.get('riskLevel', '').strip(),
            'alertMessage': request.form.get('alertMessage', '').strip(),
            'recommendations': request.form.get('recommendations', '').strip()
        }
        
        # Validate form data
        errors = validate_form_data(form_data)
        
        if errors:
            for error in errors:
                flash(error, 'danger')
            return render_template('index.html', to_mail=to_mail)
        
        # Send email
        if send_risk_alert(form_data):
            flash('Risk alert submitted successfully! The concerned department has been notified.', 'success')
            # Redirect to clear form (POST-REDIRECT-GET pattern)
            return redirect(url_for('index'))
        else:
            flash('Failed to send risk alert. Please try again or contact system administrator.', 'danger')
    
    return render_template('index.html', to_mail=to_mail)

@app.errorhandler(404)
def not_found_error(error):
    return render_template('error.html', message='Page not found'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('error.html', message='Internal server error'), 500


@app.route('/send_test', methods=['GET', 'POST'])
def send_test():
    """Route to send a preset test alert from the web UI. Useful for quick verification."""
    # Build sample data similar to send_test.py
    sample = {
        'studentName': 'Web Test Student',
        'studentEmail': 'webtest@example.com',
        'riskLevel': 'Medium',
        'alertMessage': 'This is a test alert triggered from the web UI.',
        'recommendations': 'Please follow up as needed.'
    }

    success = send_risk_alert(sample)
    if success:
        flash('Test risk alert sent successfully!', 'success')
    else:
        flash('Failed to send test alert. Check server logs.', 'danger')

    return redirect(url_for('index'))

if __name__ == '__main__':
    debug_mode = os.getenv('DEBUG', 'False').lower() == 'true'
    port = int(os.getenv('PORT', 5000))
    host = os.getenv('HOST', '0.0.0.0')
    
    app.run(host=host, port=port, debug=debug_mode)