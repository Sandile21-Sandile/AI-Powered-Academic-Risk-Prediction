def send_risk_alert(data):
	print('Risk alert sent:', data)
	return True
